// 数据结构与存储 key 的唯一来源。
// 改字段时同步 SCHEMA_VERSION，方便日后做迁移。

const SCHEMA_VERSION = 1

const KEYS = {
  recipes: 'fd.recipes.v1',
  logs: 'fd.logs.v1',
  plans: 'fd.plans.v1',
  shopping: 'fd.shopping.v1',
  settings: 'fd.settings.v1',
  draft: 'fd.draft.v1'
}

const DEFAULT_CATEGORIES = [
  { id: 'c_01', name: '家常菜' },
  { id: 'c_02', name: '汤羹' },
  { id: 'c_03', name: '主食' },
  { id: 'c_04', name: '烘焙' },
  { id: 'c_05', name: '饮品' },
  { id: 'c_06', name: '凉菜' }
]

const DIFFICULTY_TEXT = ['', '简单', '中等', '困难']

function createRecipe(overrides) {
  const now = Date.now()
  const base = {
    id: '',
    title: '',
    cover: '',                 // 相对 USER_DATA_PATH 的路径，绝对不要存 base64
    categoryId: 'c_01',
    tags: [],
    difficulty: 2,             // 1 简单 2 中等 3 困难
    durationMin: 30,
    servings: 2,
    ingredients: [{ name: '', amount: '', unit: '', optional: false }],
    steps: [{ text: '', images: [], timerSec: 0 }],
    notes: '',
    rating: 0,
    cookCount: 0,
    lastCookedAt: 0,
    createdAt: now,
    updatedAt: now
  }
  return Object.assign(base, overrides || {})
}

function createLog(overrides) {
  const base = {
    id: '',
    recipeId: '',
    date: '',
    rating: 0,
    note: '',
    photos: [],
    createdAt: Date.now()
  }
  return Object.assign(base, overrides || {})
}

function createShopping(overrides) {
  const base = {
    id: '',
    name: '',
    amount: '',
    unit: '',
    checked: false,
    fromRecipeId: '',
    createdAt: Date.now()
  }
  return Object.assign(base, overrides || {})
}

function createPlan(overrides) {
  const base = {
    id: '',
    date: '',              // 2026-09-09
    mealType: 'dinner',    // breakfast | lunch | dinner
    recipeId: '',
    done: false
  }
  return Object.assign(base, overrides || {})
}

function createSettings() {
  return {
    schemaVersion: SCHEMA_VERSION,
    categories: DEFAULT_CATEGORIES.slice(),
    sortBy: 'recent',
    randomCount: 3,
    lastBackupAt: 0
  }
}

module.exports = {
  SCHEMA_VERSION,
  KEYS,
  DEFAULT_CATEGORIES,
  DIFFICULTY_TEXT,
  createRecipe,
  createLog,
  createShopping,
  createPlan,
  createSettings
}
