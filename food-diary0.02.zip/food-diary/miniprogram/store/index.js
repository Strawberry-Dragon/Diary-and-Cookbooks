// 极简发布订阅。数据本身存在 storage，这里只负责通知页面刷新。
const listeners = {}

const store = {
  on(event, fn) {
    if (!listeners[event]) listeners[event] = []
    listeners[event].push(fn)
  },

  off(event, fn) {
    if (!listeners[event]) return
    listeners[event] = listeners[event].filter(function (item) {
      return item !== fn
    })
  },

  emit(event, payload) {
    ;(listeners[event] || []).forEach(function (fn) {
      fn(payload)
    })
  }
}

module.exports = store
