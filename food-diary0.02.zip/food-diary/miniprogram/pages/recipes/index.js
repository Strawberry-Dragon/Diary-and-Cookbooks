const recipeService = require('../../services/recipe')
const storage = require('../../services/storage')
const { debounce } = require('../../utils/debounce')

const SORT_OPTIONS = [
  { key: 'recent', label: '最近更新' },
  { key: 'most', label: '做得最多' },
  { key: 'rating', label: '评分最高' }
]

Page({
  data: {
    keyword: '',
    categoryId: '',
    sortBy: 'recent',
    categories: [],
    sortOptions: SORT_OPTIONS,
    list: [],
    total: 0,
    showBackupTip: false
  },

  onLoad() {
    this.runSearch = debounce(() => this.load(), 200)
  },

  onShow() {
    const settings = storage.get(storage.KEYS.settings, {})
    this.setData({ categories: (settings.categories || []).slice() })
    this.load()
    this.checkBackupTip()
  },

  // 攒了 5 道菜还没备份过，就提醒一次；关掉后本次会话不再出现
  checkBackupTip() {
    if (this.tipDismissed) return
    const settings = storage.get(storage.KEYS.settings, {})
    const show = !settings.lastBackupAt && recipeService.all().length >= 5
    this.setData({ showBackupTip: show })
  },

  hideBackupTip() {
    this.tipDismissed = true
    this.setData({ showBackupTip: false })
  },

  goBackup() {
    wx.navigateTo({ url: '/pages/backup/index' })
  },

  goRandom() {
    wx.navigateTo({ url: '/pages/random/index' })
  },

  load() {
    const list = recipeService.query({
      keyword: this.data.keyword,
      categoryId: this.data.categoryId,
      sortBy: this.data.sortBy
    })
    this.setData({
      list: list,
      total: recipeService.all().length
    })
  },

  onKeyword(e) {
    this.setData({ keyword: e.detail.value })
    this.runSearch()
  },

  clearKeyword() {
    this.setData({ keyword: '' })
    this.load()
  },

  onPickCategory(e) {
    const id = e.currentTarget.dataset.id || ''
    this.setData({ categoryId: id })
    this.load()
  },

  onSort(e) {
    const key = e.currentTarget.dataset.key
    this.setData({ sortBy: key })
    const settings = storage.get(storage.KEYS.settings, {})
    settings.sortBy = key
    storage.set(storage.KEYS.settings, settings)
    this.load()
  },

  goCreate() {
    wx.navigateTo({ url: '/pages/recipe-edit/index' })
  },

  goDetail(e) {
    wx.navigateTo({
      url: '/pages/recipe-detail/index?id=' + e.detail.id
    })
  }
})
