const recipeService = require('../../services/recipe')
const storage = require('../../services/storage')
const media = require('../../services/media')
const schema = require('../../store/schema')
const store = require('../../store/index')
const { debounce } = require('../../utils/debounce')

const DIFFICULTY = [
  { value: 1, label: '简单' },
  { value: 2, label: '中等' },
  { value: 3, label: '困难' }
]

Page({
  data: {
    isNew: true,
    form: schema.createRecipe(),
    tagsText: '',
    stepTimers: [0],
    categories: [],
    difficultyOptions: DIFFICULTY,
    coverSrc: '',
    stepImgs: [[]],
    saving: false
  },

  onLoad(options) {
    const settings = storage.get(storage.KEYS.settings, {})
    this.setData({ categories: (settings.categories || schema.DEFAULT_CATEGORIES) })

    this.autosave = debounce(() => {
      if (this.data.isNew) storage.set(storage.KEYS.draft, this.data.form)
    }, 500)

    if (options && options.id) {
      const recipe = recipeService.get(options.id)
      if (!recipe) {
        wx.showToast({ title: '菜谱不存在', icon: 'none' })
        setTimeout(() => wx.navigateBack(), 800)
        return
      }
      this.setData({
        isNew: false,
        form: JSON.parse(JSON.stringify(recipe)),
        tagsText: (recipe.tags || []).join('，'),
        stepTimers: (recipe.steps || []).map(function (s) {
          return s.timerSec ? s.timerSec / 60 : 0
        }),
        stepImgs: (recipe.steps || []).map(function (s) {
          return (s.images || []).map(function (p) { return media.absPath(p) })
        }),
        coverSrc: recipe.cover ? media.absPath(recipe.cover) : ''
      })
      wx.setNavigationBarTitle({ title: '编辑菜谱' })
    } else {
      wx.setNavigationBarTitle({ title: '新建菜谱' })
      const draft = storage.get(storage.KEYS.draft, null)
      if (draft && draft.title) {
        this.setData({
          form: draft,
          tagsText: (draft.tags || []).join('，'),
          stepImgs: (draft.steps || []).map(function (s) {
            return (s.images || []).map(function (p) { return media.absPath(p) })
          }),
          coverSrc: draft.cover ? media.absPath(draft.cover) : ''
        })
        wx.showToast({ title: '已恢复上次编辑', icon: 'none' })
      }
    }
  },

  // ---- 基础字段 ----

  onField(e) {
    const field = e.currentTarget.dataset.field
    this.setData({ ['form.' + field]: e.detail.value })
    this.autosave()
  },

  onNumber(e) {
    const field = e.currentTarget.dataset.field
    const value = e.detail.value === '' ? 0 : Number(e.detail.value)
    this.setData({ ['form.' + field]: value })
    this.autosave()
  },

  onTags(e) {
    this.setData({ tagsText: e.detail.value })
    this.autosave()
  },

  onPickCategory(e) {
    this.setData({ 'form.categoryId': e.currentTarget.dataset.id })
    this.autosave()
  },

  onPickDifficulty(e) {
    this.setData({ 'form.difficulty': Number(e.currentTarget.dataset.value) })
    this.autosave()
  },

  // ---- 封面 ----

  async pickCover() {
    const files = await media.pickImage(1)
    if (!files.length) return
    const rel = await media.saveImage(files[0], 'cover')
    if (!rel) {
      wx.showToast({ title: '图片保存失败', icon: 'none' })
      return
    }
    // 旧封面不在这里删，交给启动时的 GC 统一回收，避免取消编辑时误删
    this.setData({
      'form.cover': rel,
      coverSrc: media.absPath(rel)
    })
    this.autosave()
  },

  removeCover() {
    this.setData({ 'form.cover': '', coverSrc: '' })
    this.autosave()
  },

  // ---- 食材 ----

  addIngredient() {
    const list = this.data.form.ingredients.concat([
      { name: '', amount: '', unit: '', optional: false }
    ])
    this.setData({ 'form.ingredients': list })
  },

  removeIngredient(e) {
    const index = e.currentTarget.dataset.index
    const list = this.data.form.ingredients.slice()
    list.splice(index, 1)
    this.setData({ 'form.ingredients': list })
  },

  onIngredient(e) {
    const index = e.currentTarget.dataset.index
    const field = e.currentTarget.dataset.field
    this.setData({ ['form.ingredients[' + index + '].' + field]: e.detail.value })
    this.autosave()
  },

  toggleOptional(e) {
    const index = e.currentTarget.dataset.index
    const current = this.data.form.ingredients[index].optional
    this.setData({ ['form.ingredients[' + index + '].optional']: !current })
    this.autosave()
  },

  // ---- 步骤 ----

  addStep() {
    const steps = this.data.form.steps.concat([{ text: '', images: [], timerSec: 0 }])
    const timers = this.data.stepTimers.concat([0])
    const imgs = this.data.stepImgs.concat([[]])
    this.setData({ 'form.steps': steps, stepTimers: timers, stepImgs: imgs })
  },

  removeStep(e) {
    const index = e.currentTarget.dataset.index
    const steps = this.data.form.steps.slice()
    const timers = this.data.stepTimers.slice()
    const imgs = this.data.stepImgs.slice()
    steps.splice(index, 1)
    timers.splice(index, 1)
    imgs.splice(index, 1)
    this.setData({ 'form.steps': steps, stepTimers: timers, stepImgs: imgs })
  },

  onStep(e) {
    const index = e.currentTarget.dataset.index
    this.setData({ ['form.steps[' + index + '].text']: e.detail.value })
    this.autosave()
  },

  onStepTimer(e) {
    const index = e.currentTarget.dataset.index
    const minutes = e.detail.value === '' ? 0 : Number(e.detail.value)
    this.setData({ ['stepTimers[' + index + ']']: minutes })
    this.autosave()
  },

  // ---- 步骤配图 ----

  syncStepImgs(index, rels) {
    this.setData({
      ['form.steps[' + index + '].images']: rels,
      ['stepImgs[' + index + ']']: rels.map(function (p) { return media.absPath(p) })
    })
  },

  async pickStepImage(e) {
    const index = e.currentTarget.dataset.index
    const current = (this.data.form.steps[index].images || []).slice()
    const remain = 3 - current.length
    if (remain <= 0) {
      wx.showToast({ title: '每步最多 3 张', icon: 'none' })
      return
    }

    const files = await media.pickImage(remain)
    if (!files.length) return

    const rels = current.slice()
    for (let i = 0; i < files.length; i++) {
      const rel = await media.saveImage(files[i], 'step')
      if (rel) rels.push(rel)
    }

    this.syncStepImgs(index, rels)
    this.autosave()
  },

  removeStepImage(e) {
    const index = e.currentTarget.dataset.index
    const imgIndex = e.currentTarget.dataset.imgindex
    const rels = (this.data.form.steps[index].images || []).slice()
    rels.splice(imgIndex, 1)
    this.syncStepImgs(index, rels)
    this.autosave()
  },

  // ---- 保存 ----

  save() {
    if (this.data.saving) return

    const form = this.data.form
    const title = (form.title || '').trim()
    if (!title) {
      wx.showToast({ title: '先给这道菜起个名字', icon: 'none' })
      return
    }

    this.setData({ saving: true })

    const tags = (this.data.tagsText || '')
      .split(/[，,、\s]+/)
      .map(function (t) { return t.trim() })
      .filter(function (t) { return !!t })

    const ingredients = (form.ingredients || []).filter(function (i) {
      return (i.name || '').trim()
    })

    const steps = (form.steps || [])
      .map((s, i) => {
        return {
          text: (s.text || '').trim(),
          images: s.images || [],
          timerSec: Math.round((this.data.stepTimers[i] || 0) * 60)
        }
      }, this)
      .filter(function (s) { return s.text })

    const payload = Object.assign({}, form, {
      title: title,
      tags: tags,
      ingredients: ingredients,
      steps: steps,
      notes: (form.notes || '').trim()
    })

    recipeService.save(payload)
    storage.remove(storage.KEYS.draft)
    store.emit('recipes:change')

    wx.showToast({ title: '已保存', icon: 'success' })
    setTimeout(() => wx.navigateBack(), 600)
  },

  cancel() {
    if (this.data.isNew) {
      // 草稿保留，下次进来会提示恢复
      wx.navigateBack()
      return
    }
    wx.navigateBack()
  }
})
