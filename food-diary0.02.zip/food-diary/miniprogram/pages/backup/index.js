const backup = require('../../services/backup')
const storage = require('../../services/storage')
const recipeService = require('../../services/recipe')
const { formatDate } = require('../../utils/date')

Page({
  data: {
    recipeCount: 0,
    logCount: 0,
    quotaText: '',
    lastBackupText: '从未备份',
    pending: null
  },

  onShow() {
    this.refresh()
  },

  refresh() {
    const quota = storage.getQuota()
    const last = backup.lastBackupAt()
    this.setData({
      recipeCount: recipeService.all().length,
      logCount: storage.get(storage.KEYS.logs, []).length,
      quotaText: quota.currentText + ' / ' + quota.limitText,
      lastBackupText: last ? formatDate(last) : '从未备份'
    })
  },

  // ---- 导出 ----

  onExport() {
    let filePath = ''
    try {
      filePath = backup.writeBackupFile()
    } catch (e) {
      wx.showToast({ title: '生成备份失败', icon: 'none' })
      return
    }

    const that = this
    wx.shareFileMessage({
      filePath: filePath,
      fileName: '美食日记备份.txt',
      success() {
        backup.markBackedUp()
        that.refresh()
      },
      fail() {
        // 部分微信版本对可分享的文件类型有限制，txt 可能被拒，退化为复制
        wx.showModal({
          title: '无法直接分享',
          content: '当前微信版本可能不支持分享 txt 文件，改为复制到剪贴板？',
          confirmText: '复制',
          success(res) {
            if (res.confirm) that.onCopy()
          }
        })
      }
    })
  },

  onCopy() {
    const that = this
    wx.setClipboardData({
      data: backup.serialize(),
      success() {
        backup.markBackedUp()
        that.refresh()
        wx.showToast({ title: '已复制到剪贴板', icon: 'success' })
      }
    })
  },

  // ---- 导入 ----

  onImport() {
    const that = this
    wx.chooseMessageFile({
      count: 1,
      type: 'file',
      success(res) {
        const file = res.tempFiles && res.tempFiles[0]
        if (!file) return

        let text = ''
        try {
          text = wx.getFileSystemManager().readFileSync(file.path, 'utf8')
        } catch (e) {
          wx.showToast({ title: '读取文件失败', icon: 'none' })
          return
        }

        let payload = null
        try {
          payload = backup.parse(text)
        } catch (e) {
          wx.showToast({ title: e.message, icon: 'none' })
          return
        }

        that.pendingPayload = payload
        that.setData({
          pending: {
            count: backup.countRecipes(payload),
            exportedAt: payload.exportedAt ? formatDate(payload.exportedAt) : '未知'
          }
        })
      }
    })
  },

  cancelImport() {
    this.pendingPayload = null
    this.setData({ pending: null })
  },

  onMerge() {
    this.doImport('merge')
  },

  onReplace() {
    const that = this
    wx.showModal({
      title: '覆盖恢复',
      content: '会清空本机现有数据，只保留备份里的内容，确定吗？',
      confirmText: '覆盖',
      confirmColor: '#C0392B',
      success(res) {
        if (res.confirm) that.doImport('replace')
      }
    })
  },

  doImport(mode) {
    if (!this.pendingPayload) return
    const result = backup.applyImport(this.pendingPayload, mode)

    this.pendingPayload = null
    this.setData({ pending: null })

    const text = mode === 'replace'
      ? '已恢复 ' + result.added + ' 道菜'
      : '新增 ' + result.added + ' 条，跳过重复 ' + result.skipped + ' 条'

    wx.showToast({ title: text, icon: 'success', duration: 2500 })
    this.refresh()
  }
})
