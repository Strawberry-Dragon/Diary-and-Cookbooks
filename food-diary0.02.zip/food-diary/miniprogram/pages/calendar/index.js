const stats = require('../../services/stats')
const recipeService = require('../../services/recipe')
const { formatDate } = require('../../utils/date')

const WEEKDAYS = ['日', '一', '二', '三', '四', '五', '六']

Page({
  data: {
    weekdays: WEEKDAYS,
    year: 0,
    month: 0,
    monthText: '',
    cells: [],
    today: '',
    streak: 0,
    monthCount: 0,
    totalCook: 0,
    recipeCount: 0,
    selectedDate: '',
    dayItems: []
  },

  onShow() {
    const now = new Date()
    this.setData({ today: formatDate(now) })
    this.loadMonth(now.getFullYear(), now.getMonth() + 1)
  },

  loadMonth(year, month) {
    const summary = stats.summary(year, month)
    this.setData({
      year: year,
      month: month,
      monthText: year + ' 年 ' + month + ' 月',
      cells: stats.monthGrid(year, month),
      streak: summary.streak,
      monthCount: summary.monthCount,
      totalCook: summary.totalCook,
      recipeCount: summary.recipeCount,
      selectedDate: '',
      dayItems: []
    })
  },

  shiftMonth(step) {
    let year = this.data.year
    let month = this.data.month + step
    if (month < 1) { month = 12; year -= 1 }
    if (month > 12) { month = 1; year += 1 }
    this.loadMonth(year, month)
  },

  prevMonth() {
    this.shiftMonth(-1)
  },

  nextMonth() {
    this.shiftMonth(1)
  },

  goToday() {
    const now = new Date()
    this.loadMonth(now.getFullYear(), now.getMonth() + 1)
  },

  onSelectDay(e) {
    const date = e.currentTarget.dataset.date
    if (!date) return

    const items = stats.dayLogs(date).map(function (log) {
      const recipe = log.recipeId ? recipeService.get(log.recipeId) : null
      return {
        title: recipe ? recipe.title : '（菜谱已删除）',
        rating: log.rating || 0,
        note: log.note || ''
      }
    })

    this.setData({ selectedDate: date, dayItems: items })
  },

  closeDay() {
    this.setData({ selectedDate: '', dayItems: [] })
  },

  noop() {},

  goStats() {
    wx.navigateTo({ url: '/pages/stats/index' })
  }
})
