const shopping = require('../../services/shopping')
const recipeService = require('../../services/recipe')

Page({
  data: {
    items: [],
    unchecked: 0,
    name: '',
    amount: '',
    unit: '',
    showPicker: false,
    pickerList: []
  },

  onShow() {
    this.load()
  },

  load() {
    const items = shopping.all()
    this.setData({
      items: items,
      unchecked: items.filter(function (i) { return !i.checked }).length
    })
  },

  onName(e) { this.setData({ name: e.detail.value }) },
  onAmount(e) { this.setData({ amount: e.detail.value }) },
  onUnit(e) { this.setData({ unit: e.detail.value }) },

  onAdd() {
    const name = (this.data.name || '').trim()
    if (!name) {
      wx.showToast({ title: '先填食材名', icon: 'none' })
      return
    }
    shopping.add({
      name: name,
      amount: (this.data.amount || '').trim(),
      unit: (this.data.unit || '').trim()
    })
    this.setData({ name: '', amount: '', unit: '' })
    this.load()
  },

  onToggle(e) {
    shopping.toggle(e.currentTarget.dataset.id)
    this.load()
  },

  onRemove(e) {
    shopping.remove(e.currentTarget.dataset.id)
    this.load()
  },

  onClearChecked() {
    const that = this
    wx.showModal({
      title: '清空已购',
      content: '已勾选的项目会被删除，确定吗？',
      success(res) {
        if (!res.confirm) return
        shopping.clearChecked()
        that.load()
      }
    })
  },

  // ---- 从菜谱导入 ----

  openPicker() {
    const list = recipeService.all().map(function (r) {
      return { id: r.id, title: r.title, selected: false }
    })
    if (!list.length) {
      wx.showToast({ title: '还没有菜谱', icon: 'none' })
      return
    }
    this.setData({ pickerList: list, showPicker: true })
  },

  closePicker() {
    this.setData({ showPicker: false })
  },

  togglePick(e) {
    const index = e.currentTarget.dataset.index
    const current = this.data.pickerList[index].selected
    this.setData({ ['pickerList[' + index + '].selected']: !current })
  },

  confirmImport() {
    const ids = this.data.pickerList
      .filter(function (r) { return r.selected })
      .map(function (r) { return r.id })

    if (!ids.length) {
      wx.showToast({ title: '先选几道菜', icon: 'none' })
      return
    }

    const result = shopping.importFromRecipes(ids)
    this.setData({ showPicker: false })
    this.load()

    wx.showToast({
      title: '新增 ' + result.added + ' 项，合并 ' + result.merged + ' 项',
      icon: 'success',
      duration: 2500
    })
  },

  noop() {},

  goPlan() {
    wx.navigateTo({ url: '/pages/plan/index' })
  }
})
