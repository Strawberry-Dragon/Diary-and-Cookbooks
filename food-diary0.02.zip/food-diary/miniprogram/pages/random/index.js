const recipeService = require('../../services/recipe')
const storage = require('../../services/storage')

const DEFAULT_COUNT = 3

Page({
  data: {
    list: [],
    count: DEFAULT_COUNT,
    total: 0,
    maxCount: 1,
    empty: false
  },

  onShow() {
    const total = recipeService.all().length
    const maxCount = Math.max(1, total)
    const settings = storage.get(storage.KEYS.settings, {})
    let count = settings.randomCount || DEFAULT_COUNT
    if (typeof count !== 'number' || count < 1) count = 1
    if (count > maxCount) count = maxCount

    this.setData({
      total: total,
      maxCount: maxCount,
      count: count,
      empty: total === 0
    })

    if (total > 0) this.roll()
    else this.setData({ list: [] })
  },

  roll() {
    const list = recipeService.random(this.data.count)
    this.setData({ list: list })
  },

  dec() {
    if (this.data.count <= 1) return
    this.changeCount(this.data.count - 1)
  },

  inc() {
    if (this.data.count >= this.data.maxCount) return
    this.changeCount(this.data.count + 1)
  },

  // 数量变化即持久化到 settings，下次进入沿用
  changeCount(n) {
    const settings = storage.get(storage.KEYS.settings, {})
    settings.randomCount = n
    storage.set(storage.KEYS.settings, settings)
    this.setData({ count: n })
    this.roll()
  },

  onRoll() {
    this.roll()
  },

  goDetail(e) {
    wx.navigateTo({ url: '/pages/recipe-detail/index?id=' + e.detail.id })
  },

  goCreate() {
    wx.navigateTo({ url: '/pages/recipe-edit/index' })
  }
})
