const recipeService = require('../../services/recipe')
const media = require('../../services/media')
const { fromNow } = require('../../utils/date')

Page({
  data: {
    id: '',
    recipe: null,
    stepsView: [],
    hasSteps: false,
    coverSrc: '',
    categoryName: '',
    updatedText: '',
    lastCookedText: '',
    stars: ''
  },

  onLoad(options) {
    this.setData({ id: options.id || '' })
  },

  onShow() {
    this.load()
  },

  load() {
    const recipe = recipeService.get(this.data.id)
    if (!recipe) {
      this.setData({ recipe: null })
      return
    }

    const rating = recipe.rating || 0
    const stepsView = (recipe.steps || []).map(function (s) {
      return {
        text: s.text,
        imgs: (s.images || []).map(function (p) { return media.absPath(p) }),
        timerMin: s.timerSec ? Math.round(s.timerSec / 60) : 0
      }
    })

    this.setData({
      recipe: recipe,
      stepsView: stepsView,
      hasSteps: stepsView.length > 0,
      coverSrc: recipe.cover ? media.absPath(recipe.cover) : '',
      categoryName: recipeService.categoryName(recipe.categoryId),
      updatedText: fromNow(recipe.updatedAt),
      lastCookedText: recipe.lastCookedAt ? fromNow(recipe.lastCookedAt) : '还没做过',
      stars: '★★★★★'.slice(0, rating) + '☆☆☆☆☆'.slice(0, 5 - rating)
    })

    wx.setNavigationBarTitle({ title: recipe.title || '菜谱详情' })
  },

  onEdit() {
    wx.navigateTo({
      url: '/pages/recipe-edit/index?id=' + this.data.id
    })
  },

  goCook() {
    if (!this.data.hasSteps) {
      wx.showToast({ title: '先去补几个步骤', icon: 'none' })
      return
    }
    wx.navigateTo({
      url: '/pages/cooking/index?id=' + this.data.id
    })
  },

  onCook() {
    recipeService.recordCook(this.data.id, 0)
    wx.showToast({ title: '已记录一次下厨', icon: 'success' })
    this.load()
  },

  onDelete() {
    const that = this
    wx.showModal({
      title: '删除菜谱',
      content: '删除后无法恢复，确定吗？',
      confirmColor: '#C0392B',
      success(res) {
        if (!res.confirm) return
        recipeService.remove(that.data.id)
        wx.showToast({ title: '已删除', icon: 'success' })
        setTimeout(() => wx.navigateBack(), 600)
      }
    })
  }
})
