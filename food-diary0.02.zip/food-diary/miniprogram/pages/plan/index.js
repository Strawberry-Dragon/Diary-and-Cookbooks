const planService = require('../../services/plan')
const recipeService = require('../../services/recipe')

Page({
  data: {
    days: [],
    rangeText: '',
    showPicker: false,
    pickerList: [],
    activeDate: '',
    activeMeal: '',
    activeMealLabel: ''
  },

  onShow() {
    if (!this.baseTs) this.baseTs = Date.now()
    this.load()
  },

  load() {
    const days = planService.weekBoard(new Date(this.baseTs))
    const first = days[0].date
    const last = days[6].date
    this.setData({
      days: days,
      rangeText: Number(first.slice(5, 7)) + '月' + Number(first.slice(8, 10)) + '日 - '
        + Number(last.slice(5, 7)) + '月' + Number(last.slice(8, 10)) + '日'
    })
  },

  shiftWeek(step) {
    this.baseTs = this.baseTs + step * 7 * 86400000
    this.load()
  },

  prevWeek() { this.shiftWeek(-1) },
  nextWeek() { this.shiftWeek(1) },

  goThisWeek() {
    this.baseTs = Date.now()
    this.load()
  },

  openPicker(e) {
    const list = recipeService.all().map(function (r) {
      return { id: r.id, title: r.title }
    })
    if (!list.length) {
      wx.showToast({ title: '还没有菜谱', icon: 'none' })
      return
    }

    const meal = e.currentTarget.dataset.meal
    const label = meal === 'breakfast' ? '早餐' : meal === 'lunch' ? '午餐' : '晚餐'

    this.setData({
      pickerList: list,
      showPicker: true,
      activeDate: e.currentTarget.dataset.date,
      activeMeal: meal,
      activeMealLabel: label
    })
  },

  closePicker() {
    this.setData({ showPicker: false })
  },

  pickRecipe(e) {
    planService.assign(this.data.activeDate, this.data.activeMeal, e.currentTarget.dataset.id)
    this.setData({ showPicker: false })
    this.load()
  },

  clearSlot(e) {
    planService.assign(e.currentTarget.dataset.date, e.currentTarget.dataset.meal, '')
    this.load()
  },

  toggleDone(e) {
    planService.toggleDone(e.currentTarget.dataset.id)
    this.load()
  },

  noop() {}
})
