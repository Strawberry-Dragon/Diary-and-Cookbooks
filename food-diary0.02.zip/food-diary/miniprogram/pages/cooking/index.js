const recipeService = require('../../services/recipe')
const media = require('../../services/media')
const { formatClock } = require('../../utils/date')

Page({
  data: {
    id: '',
    title: '',
    total: 0,
    stepIndex: 0,
    isLast: false,
    percent: 0,
    steps: [],
    ingredients: [],
    showIngredients: false,

    timerTotal: 0,
    timerLeft: 0,
    clockText: '00:00',
    timerRunning: false
  },

  onLoad(options) {
    this.setData({ id: options.id || '' })
    // 做菜时手是脏的，屏幕不能熄
    wx.setKeepScreenOn({ keepScreenOn: true })
    this.load()
  },

  onReady() {
    this.initCanvas()
  },

  onShow() {
    // 切后台再回来，按时间戳立即补算一次，避免倒计时走偏
    this.tick()
  },

  onUnload() {
    wx.setKeepScreenOn({ keepScreenOn: false })
    this.stopTick()
  },

  load() {
    const recipe = recipeService.get(this.data.id)
    if (!recipe) {
      wx.showToast({ title: '菜谱不存在', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 800)
      return
    }

    const steps = (recipe.steps || []).map(function (s) {
      return {
        text: s.text,
        imgs: (s.images || []).map(function (p) { return media.absPath(p) }),
        timerSec: s.timerSec || 0
      }
    })

    if (!steps.length) {
      wx.showToast({ title: '这道菜还没有步骤', icon: 'none' })
      setTimeout(() => wx.navigateBack(), 800)
      return
    }

    this.setData({
      title: recipe.title,
      total: steps.length,
      steps: steps,
      ingredients: (recipe.ingredients || []).filter(function (i) {
        return (i.name || '').trim()
      })
    })

    wx.setNavigationBarTitle({ title: recipe.title })
    this.goStep(0)
  },

  // ---- 步骤切换 ----

  goStep(index) {
    if (index < 0 || index >= this.data.total) return
    this.setData({
      stepIndex: index,
      isLast: index === this.data.total - 1,
      percent: Math.round(((index + 1) / this.data.total) * 100)
    })
    this.prepareTimer(index)
  },

  onSwipe(e) {
    this.goStep(e.detail.current)
  },

  next() {
    if (this.data.isLast) {
      this.askRecord()
      return
    }
    this.goStep(this.data.stepIndex + 1)
  },

  prev() {
    this.goStep(this.data.stepIndex - 1)
  },

  toggleIngredients() {
    this.setData({ showIngredients: !this.data.showIngredients })
  },

  noop() {},

  // ---- 计时器 ----
  // 关键：始终用 endTime 时间戳计算剩余，不用 setInterval 累加，
  // 否则小程序切到后台被节流后时间会明显走偏。

  prepareTimer(index) {
    this.stopTick()
    const total = (this.data.steps[index] && this.data.steps[index].timerSec) || 0
    this.setData({
      timerTotal: total,
      timerLeft: total,
      clockText: formatClock(total),
      timerRunning: false
    })
    this.drawRing(total ? 1 : 0)
  },

  // WXML 不支持动态事件名，统一从这里分发
  onTimerToggle() {
    if (this.data.timerRunning) this.pauseTimer()
    else this.startTimer()
  },

  startTimer() {
    if (!this.data.timerTotal) return
    if (this.data.timerRunning) return
    const left = this.data.timerLeft > 0 ? this.data.timerLeft : this.data.timerTotal
    this.timerEndAt = Date.now() + left * 1000
    this.setData({ timerRunning: true })
    this.startTick()
  },

  pauseTimer() {
    if (!this.data.timerRunning) return
    this.stopTick()
    const left = Math.max(0, Math.round((this.timerEndAt - Date.now()) / 1000))
    this.setData({ timerRunning: false, timerLeft: left, clockText: formatClock(left) })
    this.drawRing(this.data.timerTotal ? left / this.data.timerTotal : 0)
  },

  resetTimer() {
    this.stopTick()
    const total = this.data.timerTotal
    this.setData({ timerRunning: false, timerLeft: total, clockText: formatClock(total) })
    this.drawRing(total ? 1 : 0)
  },

  startTick() {
    this.stopTick()
    this.tickHandler = setInterval(() => this.tick(), 250)
  },

  stopTick() {
    if (this.tickHandler) {
      clearInterval(this.tickHandler)
      this.tickHandler = null
    }
  },

  tick() {
    if (!this.data.timerRunning) return
    const remainMs = this.timerEndAt - Date.now()
    if (remainMs <= 0) {
      this.finishTimer()
      return
    }
    const left = Math.ceil(remainMs / 1000)
    if (left === this.data.timerLeft) return
    this.setData({ timerLeft: left, clockText: formatClock(left) })
    this.drawRing(this.data.timerTotal ? left / this.data.timerTotal : 0)
  },

  finishTimer() {
    this.stopTick()
    this.setData({
      timerRunning: false,
      timerLeft: 0,
      clockText: '00:00'
    })
    this.drawRing(0)
    wx.vibrateLong()
    wx.showToast({ title: '时间到', icon: 'none', duration: 2000 })
  },

  // ---- 倒计时环 ----

  initCanvas() {
    const that = this
    wx.createSelectorQuery()
      .in(this)
      .select('#ring')
      .fields({ node: true, size: true })
      .exec(function (res) {
        if (!res || !res[0] || !res[0].node) return
        const canvas = res[0].node
        const ctx = canvas.getContext('2d')
        let dpr = 2
        try {
          const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync()
          dpr = info.pixelRatio || 2
        } catch (e) {}
        canvas.width = res[0].width * dpr
        canvas.height = res[0].height * dpr
        ctx.scale(dpr, dpr)
        that.ctx = ctx
        that.ringSize = res[0].width
        that.drawRing(that.data.timerTotal ? 1 : 0)
      })
  },

  drawRing(progress) {
    if (!this.ctx) return
    const ctx = this.ctx
    const size = this.ringSize || 120
    const cx = size / 2
    const cy = size / 2
    const r = size / 2 - 8
    const p = Math.max(0, Math.min(1, progress || 0))

    ctx.clearRect(0, 0, size, size)
    ctx.lineWidth = 8
    ctx.lineCap = 'round'

    ctx.strokeStyle = '#F1EFE8'
    ctx.beginPath()
    ctx.arc(cx, cy, r, 0, Math.PI * 2)
    ctx.stroke()

    if (p > 0) {
      ctx.strokeStyle = '#D85A30'
      ctx.beginPath()
      ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * p)
      ctx.stroke()
    }
  },

  // ---- 退出 ----

  askRecord() {
    const that = this
    wx.showModal({
      title: '做完了',
      content: '要记一次下厨吗？',
      confirmText: '记一次',
      cancelText: '不用',
      success(res) {
        if (res.confirm) recipeService.recordCook(that.data.id, 0)
        wx.navigateBack()
      }
    })
  },

  onExit() {
    this.askRecord()
  }
})
