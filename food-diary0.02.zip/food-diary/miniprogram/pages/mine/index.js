const storage = require('../../services/storage')
const recipeService = require('../../services/recipe')
const schema = require('../../store/schema')
const { uid } = require('../../utils/id')

const SAMPLES = [
  {
    title: '番茄牛腩',
    categoryId: 'c_01',
    tags: ['下饭', '宴客', '一锅出'],
    difficulty: 2,
    durationMin: 90,
    servings: 3,
    rating: 5,
    cookCount: 7,
    ingredients: [
      { name: '牛腩', amount: '500', unit: 'g', optional: false },
      { name: '番茄', amount: '3', unit: '个', optional: false },
      { name: '洋葱', amount: '半个', unit: '', optional: false },
      { name: '香菜', amount: '少许', unit: '', optional: true }
    ],
    steps: [
      { text: '牛腩切块，冷水下锅焯水，撇净浮沫后捞出冲洗干净', images: [], timerSec: 0 },
      { text: '热锅下油，炒香洋葱，加入番茄炒出汁水', images: [], timerSec: 0 },
      { text: '倒入牛腩翻炒上色，加开水没过食材，小火慢炖', images: [], timerSec: 3600 },
      { text: '炖至牛腩软烂，加盐调味，大火收汁，撒香菜出锅', images: [], timerSec: 600 }
    ],
    notes: '番茄分两次放：一半炖化出味，一半起锅前放保持形状。'
  },
  {
    title: '蒜香黄油虾',
    categoryId: 'c_01',
    tags: ['快手', '10分钟'],
    difficulty: 1,
    durationMin: 15,
    servings: 2,
    rating: 4,
    cookCount: 3,
    ingredients: [
      { name: '大虾', amount: '300', unit: 'g', optional: false },
      { name: '黄油', amount: '20', unit: 'g', optional: false },
      { name: '蒜', amount: '5', unit: '瓣', optional: false },
      { name: '黑胡椒', amount: '适量', unit: '', optional: true }
    ],
    steps: [
      { text: '虾开背去虾线，用厨房纸吸干水分', images: [], timerSec: 0 },
      { text: '黄油融化，下蒜末小火炒香', images: [], timerSec: 0 },
      { text: '转大火下虾，两面各煎 90 秒至变红卷曲', images: [], timerSec: 180 },
      { text: '撒黑胡椒和少许盐，出锅', images: [], timerSec: 0 }
    ],
    notes: '虾一定要吸干水，否则出水变成煮虾。'
  },
  {
    title: '味噌汤',
    categoryId: 'c_02',
    tags: ['早餐', '清淡'],
    difficulty: 1,
    durationMin: 10,
    servings: 2,
    rating: 4,
    cookCount: 12,
    ingredients: [
      { name: '味噌', amount: '2', unit: '勺', optional: false },
      { name: '嫩豆腐', amount: '半盒', unit: '', optional: false },
      { name: '海带芽', amount: '1', unit: '小把', optional: false }
    ],
    steps: [
      { text: '锅中加水煮开，放入泡发的海带芽', images: [], timerSec: 0 },
      { text: '豆腐切小块下锅，煮 2 分钟', images: [], timerSec: 120 },
      { text: '关火后化开味噌，切勿沸腾，否则鲜味会跑掉', images: [], timerSec: 0 }
    ],
    notes: '味噌一定关火后再放。'
  }
]

Page({
  data: {
    quotaText: '',
    ratioText: '',
    recipeCount: 0
  },

  onShow() {
    const quota = storage.getQuota()
    this.setData({
      quotaText: quota.currentText + ' / ' + quota.limitText,
      ratioText: Math.round(quota.ratio * 100) + '%',
      recipeCount: recipeService.all().length
    })
  },

  goBackup() {
    wx.navigateTo({ url: '/pages/backup/index' })
  },

  goStats() {
    wx.navigateTo({ url: '/pages/stats/index' })
  },

  goRandom() {
    wx.navigateTo({ url: '/pages/random/index' })
  },

  goPlan() {
    wx.navigateTo({ url: '/pages/plan/index' })
  },

  seedSamples() {
    const exist = recipeService.all()
    const titles = exist.map(function (r) { return r.title })
    let added = 0

    SAMPLES.forEach(function (sample) {
      if (titles.indexOf(sample.title) >= 0) return
      const recipe = schema.createRecipe(Object.assign({}, sample, {
        id: uid('r'),
        createdAt: Date.now(),
        updatedAt: Date.now(),
        lastCookedAt: Date.now()
      }))
      recipeService.save(recipe)
      added++
    })

    wx.showToast({
      title: added ? '已添加 ' + added + ' 道示例' : '示例已存在',
      icon: 'none'
    })
    this.onShow()
  },

  clearAll() {
    wx.showModal({
      title: '清空所有菜谱',
      content: '本地数据会被全部删除，确定吗？',
      confirmColor: '#C0392B',
      success(res) {
        if (!res.confirm) return
        storage.set(storage.KEYS.recipes, [])
        storage.set(storage.KEYS.logs, [])
        wx.showToast({ title: '已清空', icon: 'success' })
      }
    })
  }
})
