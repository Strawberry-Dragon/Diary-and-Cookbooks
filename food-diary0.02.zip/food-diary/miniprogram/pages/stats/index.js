const stats = require('../../services/stats')
const recipeService = require('../../services/recipe')

Page({
  data: {
    streak: 0,
    monthCount: 0,
    totalCook: 0,
    recipeCount: 0,
    topList: [],
    hasData: false
  },

  onShow() {
    const now = new Date()
    const summary = stats.summary(now.getFullYear(), now.getMonth() + 1)
    const top = stats.topRecipes(10).map(function (r, i) {
      return {
        id: r.id,
        rank: i + 1,
        title: r.title,
        count: r.cookCount,
        lastText: r.lastCookedAt ? '上次 ' + Math.max(1, Math.round((Date.now() - r.lastCookedAt) / 86400000)) + ' 天前' : ''
      }
    })

    this.setData({
      streak: summary.streak,
      monthCount: summary.monthCount,
      totalCook: summary.totalCook,
      recipeCount: summary.recipeCount,
      topList: top,
      hasData: top.length > 0
    })
  },

  openRecipe(e) {
    wx.navigateTo({
      url: '/pages/recipe-detail/index?id=' + e.currentTarget.dataset.id
    })
  }
})
