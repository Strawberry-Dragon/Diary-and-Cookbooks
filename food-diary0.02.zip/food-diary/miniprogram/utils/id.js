// 轻量唯一 ID，避免为此引入 uuid 依赖
function uid(prefix) {
  const t = Date.now().toString(36)
  const r = Math.random().toString(36).slice(2, 6)
  return (prefix || 'id') + '_' + t + r
}

module.exports = { uid }
