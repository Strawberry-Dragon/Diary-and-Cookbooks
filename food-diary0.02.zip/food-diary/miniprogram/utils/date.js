function pad(n) {
  return n < 10 ? '0' + n : '' + n
}

// 2026-09-09
function formatDate(input) {
  const d = input ? new Date(input) : new Date()
  return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate())
}

// 3 分钟前 / 2 天前
function fromNow(ts) {
  if (!ts) return ''
  const diff = Date.now() - ts
  if (diff < 60 * 1000) return '刚刚'
  if (diff < 60 * 60 * 1000) return Math.floor(diff / 60000) + ' 分钟前'
  if (diff < 24 * 60 * 60 * 1000) return Math.floor(diff / 3600000) + ' 小时前'
  if (diff < 30 * 24 * 3600000) return Math.floor(diff / 86400000) + ' 天前'
  return formatDate(ts)
}

// 秒 -> 05:00，超过 1 小时显示 01:05:00
function formatClock(sec) {
  const s = Math.max(0, Math.floor(sec || 0))
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const ss = s % 60
  const mm = pad(m)
  const sss = pad(ss)
  return h > 0 ? pad(h) + ':' + mm + ':' + sss : mm + ':' + sss
}

module.exports = { formatDate, fromNow, formatClock }
