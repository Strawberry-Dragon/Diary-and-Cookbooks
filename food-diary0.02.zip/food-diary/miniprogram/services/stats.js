const storage = require('./storage')
const recipeService = require('./recipe')
const { formatDate } = require('../utils/date')

function logs() {
  return storage.get(storage.KEYS.logs, [])
}

// { '2026-09-09': 2, ... }
function groupByDate() {
  const map = {}
  logs().forEach(function (l) {
    if (!l.date) return
    map[l.date] = (map[l.date] || 0) + 1
  })
  return map
}

// 42 格月历，周日为第一列
function monthGrid(year, month) {
  const first = new Date(year, month - 1, 1)
  const startWeekday = first.getDay()
  const daysInMonth = new Date(year, month, 0).getDate()
  const prevMonthDays = new Date(year, month - 1, 0).getDate()
  const map = groupByDate()

  const cells = []
  for (let i = 0; i < 42; i++) {
    const dayNum = i - startWeekday + 1
    let d
    let inMonth = true

    if (dayNum < 1) {
      d = new Date(year, month - 2, prevMonthDays + dayNum)
      inMonth = false
    } else if (dayNum > daysInMonth) {
      d = new Date(year, month, dayNum - daysInMonth)
      inMonth = false
    } else {
      d = new Date(year, month - 1, dayNum)
    }

    const dateStr = formatDate(d)
    const count = map[dateStr] || 0
    cells.push({
      date: dateStr,
      day: d.getDate(),
      inMonth: inMonth,
      count: count,
      level: count === 0 ? 0 : (count < 3 ? 1 : 2)
    })
  }
  return cells
}

function monthPrefix(year, month) {
  return formatDate(new Date(year, month - 1, 1)).slice(0, 7)
}

function monthCount(year, month) {
  const prefix = monthPrefix(year, month)
  return logs().filter(function (l) {
    return (l.date || '').indexOf(prefix) === 0
  }).length
}

// 连续下厨天数：今天做了就从今天算，今天没做从昨天算（今天还没过完，不该算断）
function streak() {
  const map = groupByDate()
  const d = new Date()
  if (!map[formatDate(d)]) d.setDate(d.getDate() - 1)

  let n = 0
  while (map[formatDate(d)]) {
    n++
    d.setDate(d.getDate() - 1)
  }
  return n
}

function totalCook() {
  return logs().length
}

function topRecipes(limit) {
  return recipeService
    .all()
    .filter(function (r) { return (r.cookCount || 0) > 0 })
    .sort(function (a, b) { return b.cookCount - a.cookCount })
    .slice(0, limit || 10)
}

function dayLogs(dateStr) {
  return logs().filter(function (l) { return l.date === dateStr })
}

function summary(year, month) {
  return {
    streak: streak(),
    monthCount: monthCount(year, month),
    totalCook: totalCook(),
    recipeCount: recipeService.all().length
  }
}

module.exports = {
  logs: logs,
  groupByDate: groupByDate,
  monthGrid: monthGrid,
  monthCount: monthCount,
  streak: streak,
  totalCook: totalCook,
  topRecipes: topRecipes,
  dayLogs: dayLogs,
  summary: summary
}
