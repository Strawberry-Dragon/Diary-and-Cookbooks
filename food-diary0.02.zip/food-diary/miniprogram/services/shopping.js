const storage = require('./storage')
const schema = require('../store/schema')
const recipeService = require('./recipe')
const { uid } = require('../utils/id')

function all() {
  return storage.get(storage.KEYS.shopping, [])
}

function setAll(list) {
  storage.set(storage.KEYS.shopping, list)
}

function add(item) {
  const list = all()
  const row = schema.createShopping(Object.assign({ id: uid('s') }, item))
  list.push(row)
  setAll(list)
  return row
}

function remove(id) {
  setAll(all().filter(function (i) { return i.id !== id }))
}

function toggle(id) {
  const list = all()
  const item = list.filter(function (i) { return i.id === id })[0]
  if (!item) return
  item.checked = !item.checked
  setAll(list)
}

function clearChecked() {
  setAll(all().filter(function (i) { return !i.checked }))
}

// 数值相加，"少许""适量"这类非数值加不起来就返回 null（保持原样，不硬合并）
function trySum(a, b) {
  const na = parseFloat(a)
  const nb = parseFloat(b)
  if (isNaN(na) || isNaN(nb)) return null
  return String(Math.round((na + nb) * 100) / 100)
}

// 从若干菜谱导入食材，按「名称+单位」合并同类：牛腩 500g + 300g = 800g
function importFromRecipes(ids) {
  const list = all()
  const index = {}
  list.forEach(function (i) {
    index[i.name + '|' + (i.unit || '')] = i
  })

  let added = 0
  let merged = 0

  ;(ids || []).forEach(function (id) {
    const recipe = recipeService.get(id)
    if (!recipe) return

    ;(recipe.ingredients || []).forEach(function (ing) {
      const name = (ing.name || '').trim()
      if (!name) return

      const unit = (ing.unit || '').trim()
      const amount = (ing.amount || '').trim()
      const key = name + '|' + unit

      if (index[key]) {
        const current = index[key]
        const sum = trySum(current.amount, amount)
        if (sum !== null) {
          current.amount = sum
          merged++
        }
        return
      }

      const row = schema.createShopping({
        id: uid('s'),
        name: name,
        amount: amount,
        unit: unit,
        fromRecipeId: recipe.id
      })
      list.push(row)
      index[key] = row
      added++
    })
  })

  setAll(list)
  return { added: added, merged: merged }
}

module.exports = {
  all: all,
  add: add,
  remove: remove,
  toggle: toggle,
  clearChecked: clearChecked,
  importFromRecipes: importFromRecipes,
  trySum: trySum
}
