const storage = require('./storage')
const schema = require('../store/schema')
const recipeService = require('./recipe')
const { uid } = require('../utils/id')
const { formatDate } = require('../utils/date')

const MEAL_TYPES = [
  { key: 'breakfast', label: '早餐' },
  { key: 'lunch', label: '午餐' },
  { key: 'dinner', label: '晚餐' }
]

function all() {
  return storage.get(storage.KEYS.plans, [])
}

function setAll(list) {
  storage.set(storage.KEYS.plans, list)
}

function find(date, mealType) {
  const list = all()
  for (let i = 0; i < list.length; i++) {
    if (list[i].date === date && list[i].mealType === mealType) return list[i]
  }
  return null
}

// recipeId 为空表示清除这一格
function assign(date, mealType, recipeId) {
  const list = all()
  let index = -1
  for (let i = 0; i < list.length; i++) {
    if (list[i].date === date && list[i].mealType === mealType) { index = i; break }
  }

  if (index >= 0) {
    if (recipeId) list[index].recipeId = recipeId
    else list.splice(index, 1)
  } else if (recipeId) {
    list.push(schema.createPlan({
      id: uid('p'),
      date: date,
      mealType: mealType,
      recipeId: recipeId
    }))
  }

  setAll(list)
}

function toggleDone(id) {
  const list = all()
  const item = list.filter(function (p) { return p.id === id })[0]
  if (!item) return
  item.done = !item.done
  setAll(list)
}

// 取一周 7 天（周一为第一天）
function weekDates(baseInput) {
  const base = baseInput ? new Date(baseInput) : new Date()
  const day = base.getDay()
  const diff = day === 0 ? -6 : 1 - day

  const monday = new Date(base)
  monday.setDate(base.getDate() + diff)

  const out = []
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday)
    d.setDate(monday.getDate() + i)
    out.push(formatDate(d))
  }
  return out
}

// 组装一周 × 三餐的展示数据
function weekBoard(baseInput) {
  const dates = weekDates(baseInput)
  const plans = all()
  const WEEK_LABELS = ['周一', '周二', '周三', '周四', '周五', '周六', '周日']

  return dates.map(function (date, i) {
    const meals = MEAL_TYPES.map(function (meal) {
      const plan = plans.filter(function (p) {
        return p.date === date && p.mealType === meal.key
      })[0]

      let title = ''
      if (plan && plan.recipeId) {
        const recipe = recipeService.get(plan.recipeId)
        title = recipe ? recipe.title : ''
      }

      return {
        key: meal.key,
        label: meal.label,
        date: date,
        planId: plan ? plan.id : '',
        recipeId: plan ? plan.recipeId : '',
        title: title,
        done: plan ? plan.done : false
      }
    })

    return {
      date: date,
      weekLabel: WEEK_LABELS[i],
      dayLabel: String(Number(date.slice(8, 10))),
      isToday: date === formatDate(new Date()),
      meals: meals
    }
  })
}

module.exports = {
  MEAL_TYPES: MEAL_TYPES,
  all: all,
  find: find,
  assign: assign,
  toggleDone: toggleDone,
  weekDates: weekDates,
  weekBoard: weekBoard
}
