// 图片一律存文件系统，绝不进 wx.setStorageSync（缓存上限约 10MB，放几张图就爆了）。
// 数据库里只保存相对路径，如 fd/cover/xxxx.jpg

const fs = wx.getFileSystemManager()
const ROOT = wx.env.USER_DATA_PATH + '/fd'
const DIR_COVER = ROOT + '/cover'
const DIR_STEPS = ROOT + '/steps'

const MAX_SIDE = 1280

function ensureDirs() {
  ;[ROOT, DIR_COVER, DIR_STEPS].forEach(function (dir) {
    try {
      fs.accessSync(dir)
    } catch (e) {
      try {
        fs.mkdirSync(dir, true)
      } catch (e2) {}
    }
  })
}

function pickImage(count) {
  return new Promise(function (resolve) {
    wx.chooseMedia({
      count: count || 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      sizeType: ['compressed'],
      success: function (res) {
        resolve((res.tempFiles || []).map(function (f) {
          return f.tempFilePath
        }))
      },
      fail: function () {
        resolve([])
      }
    })
  })
}

function compress(tempPath) {
  return new Promise(function (resolve) {
    wx.getImageInfo({
      src: tempPath,
      success: function (info) {
        // 横图压宽、竖图压高，避免竖图被压成 1280 宽后依然巨大
        const sizeOpt = info.width >= info.height
          ? { compressedWidth: MAX_SIDE }
          : { compressedHeight: MAX_SIDE }
        const opt = Object.assign({ src: tempPath, quality: 80 }, sizeOpt, {
          success: function (res) { resolve(res.tempFilePath) },
          fail: function () { resolve(tempPath) }
        })
        wx.compressImage(opt)
      },
      fail: function () {
        wx.compressImage({
          src: tempPath,
          quality: 80,
          compressedWidth: MAX_SIDE,
          success: function (res) { resolve(res.tempFilePath) },
          fail: function () { resolve(tempPath) }
        })
      }
    })
  })
}

// type: 'cover' | 'step'，返回相对路径
function saveImage(tempPath, type) {
  ensureDirs()
  const folder = type === 'step' ? 'steps' : 'cover'
  const name = Date.now() + '_' + Math.random().toString(36).slice(2, 8) + '.jpg'
  const rel = 'fd/' + folder + '/' + name
  const filePath = wx.env.USER_DATA_PATH + '/' + rel

  return compress(tempPath).then(function (compressed) {
    return new Promise(function (resolve) {
      fs.saveFile({
        tempFilePath: compressed,
        filePath: filePath,
        success: function () { resolve(rel) },
        fail: function () { resolve('') }
      })
    })
  })
}

function absPath(rel) {
  if (!rel) return ''
  if (rel.indexOf('fd/') === 0) return wx.env.USER_DATA_PATH + '/' + rel
  return rel
}

function removeImage(rel) {
  if (!rel) return
  try {
    fs.unlinkSync(absPath(rel))
  } catch (e) {}
}

// 汇总所有仍被引用的图片路径
function collectUsed(recipes) {
  const out = []
  ;(recipes || []).forEach(function (r) {
    if (r.cover) out.push(r.cover)
    ;(r.steps || []).forEach(function (s) {
      ;(s.images || []).forEach(function (p) {
        out.push(p)
      })
    })
  })
  return out
}

// 启动时清理无引用的孤儿图片，返回清理数量
function gc(usedRels) {
  ensureDirs()
  const used = {}
  ;(usedRels || []).forEach(function (r) { used[r] = true })

  let removed = 0
  ;[DIR_COVER, DIR_STEPS].forEach(function (dir) {
    let files = []
    try {
      files = fs.readdirSync(dir)
    } catch (e) {
      return
    }
    files.forEach(function (name) {
      const rel = 'fd/' + (dir === DIR_STEPS ? 'steps' : 'cover') + '/' + name
      if (used[rel]) return
      try {
        fs.unlinkSync(dir + '/' + name)
        removed++
      } catch (e) {}
    })
  })
  return removed
}

module.exports = {
  ensureDirs: ensureDirs,
  pickImage: pickImage,
  saveImage: saveImage,
  absPath: absPath,
  removeImage: removeImage,
  collectUsed: collectUsed,
  gc: gc
}
