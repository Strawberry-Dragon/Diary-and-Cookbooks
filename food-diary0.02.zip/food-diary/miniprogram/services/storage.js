const schema = require('../store/schema')

const KEYS = schema.KEYS

// 注意：wx.getStorageSync 在 key 不存在时返回空字符串，不是 null
function get(key, fallback) {
  try {
    const value = wx.getStorageSync(key)
    if (value === '' || value === null || value === undefined) return fallback
    return value
  } catch (e) {
    return fallback
  }
}

function set(key, data) {
  try {
    wx.setStorageSync(key, data)
    return true
  } catch (e) {
    wx.showToast({ title: '存储空间不足', icon: 'none' })
    return false
  }
}

function remove(key) {
  try {
    wx.removeStorageSync(key)
  } catch (e) {}
}

// 返回 KB 为单位的信息，以及已用比例
function getQuota() {
  try {
    const info = wx.getStorageInfoSync()
    const limitSize = info.limitSize || 10240
    const currentSize = info.currentSize || 0
    return {
      currentSize: currentSize,
      limitSize: limitSize,
      ratio: limitSize ? currentSize / limitSize : 0,
      currentText: (currentSize / 1024).toFixed(1) + ' MB',
      limitText: (limitSize / 1024).toFixed(0) + ' MB'
    }
  } catch (e) {
    return {
      currentSize: 0,
      limitSize: 10240,
      ratio: 0,
      currentText: '0 MB',
      limitText: '10 MB'
    }
  }
}

function init() {
  const settings = get(KEYS.settings, null)
  if (!settings || typeof settings !== 'object') {
    set(KEYS.settings, schema.createSettings())
  }
  ;[KEYS.recipes, KEYS.logs, KEYS.plans, KEYS.shopping].forEach(function (key) {
    if (get(key, null) === null) set(key, [])
  })
}

module.exports = {
  KEYS: KEYS,
  get: get,
  set: set,
  remove: remove,
  getQuota: getQuota,
  init: init
}
