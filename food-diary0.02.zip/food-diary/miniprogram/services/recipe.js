const storage = require('./storage')
const media = require('./media')
const schema = require('../store/schema')
const store = require('../store/index')
const { uid } = require('../utils/id')
const { formatDate } = require('../utils/date')

const KEYS = storage.KEYS

function all() {
  return storage.get(KEYS.recipes, [])
}

function get(id) {
  const list = all()
  for (let i = 0; i < list.length; i++) {
    if (list[i].id === id) return list[i]
  }
  return null
}

function save(recipe) {
  const list = all()
  recipe.updatedAt = Date.now()

  let index = -1
  for (let i = 0; i < list.length; i++) {
    if (list[i].id === recipe.id) { index = i; break }
  }

  if (index >= 0) {
    list[index] = recipe
  } else {
    recipe.id = recipe.id || uid('r')
    recipe.createdAt = recipe.createdAt || Date.now()
    list.unshift(recipe)
  }

  storage.set(KEYS.recipes, list)
  store.emit('recipes:change')
  return recipe
}

function remove(id) {
  const recipe = get(id)
  if (recipe) {
    if (recipe.cover) media.removeImage(recipe.cover)
    ;(recipe.steps || []).forEach(function (s) {
      ;(s.images || []).forEach(function (p) { media.removeImage(p) })
    })
  }
  const list = all().filter(function (r) { return r.id !== id })
  storage.set(KEYS.recipes, list)
  store.emit('recipes:change')
}

// 本地数据量小，直接全量过滤即可，无需索引或分词库
function query(options) {
  const opts = options || {}
  const keyword = (opts.keyword || '').trim().toLowerCase()
  const categoryId = opts.categoryId || ''
  const sortBy = opts.sortBy || 'recent'

  let list = all()

  if (categoryId) {
    list = list.filter(function (r) { return r.categoryId === categoryId })
  }

  if (keyword) {
    list = list.filter(function (r) {
      if ((r.title || '').toLowerCase().indexOf(keyword) >= 0) return true
      const tags = r.tags || []
      for (let i = 0; i < tags.length; i++) {
        if ((tags[i] || '').toLowerCase().indexOf(keyword) >= 0) return true
      }
      const ingredients = r.ingredients || []
      for (let j = 0; j < ingredients.length; j++) {
        if ((ingredients[j].name || '').toLowerCase().indexOf(keyword) >= 0) return true
      }
      return false
    })
  }

  list = list.slice()
  if (sortBy === 'most') {
    list.sort(function (a, b) { return (b.cookCount || 0) - (a.cookCount || 0) })
  } else if (sortBy === 'rating') {
    list.sort(function (a, b) { return (b.rating || 0) - (a.rating || 0) })
  } else {
    list.sort(function (a, b) { return (b.updatedAt || 0) - (a.updatedAt || 0) })
  }

  return list
}

function categoryName(categoryId) {
  const settings = storage.get(KEYS.settings, {})
  const list = settings.categories || schema.DEFAULT_CATEGORIES
  for (let i = 0; i < list.length; i++) {
    if (list[i].id === categoryId) return list[i].name
  }
  return ''
}

// 记一次下厨：累加次数并写一条 CookLog，供第 3 周的日历使用
function recordCook(id, rating) {
  const recipe = get(id)
  if (!recipe) return null

  recipe.cookCount = (recipe.cookCount || 0) + 1
  recipe.lastCookedAt = Date.now()
  if (rating) recipe.rating = rating
  save(recipe)

  const logs = storage.get(KEYS.logs, [])
  const log = schema.createLog({
    id: uid('l'),
    recipeId: id,
    date: formatDate(Date.now()),
    rating: rating || recipe.rating || 0
  })
  logs.push(log)
  storage.set(KEYS.logs, logs)

  return recipe
}

// 从全部菜谱里随机取 n 道（不重复）。n<=0 返回空；n>=总数返回全部。
function random(n) {
  const list = all()
  const count = Math.max(0, Math.floor(n || 0))
  if (count <= 0 || list.length === 0) return []

  const arr = list.slice()
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    const tmp = arr[i]
    arr[i] = arr[j]
    arr[j] = tmp
  }
  return arr.slice(0, Math.min(count, arr.length))
}

module.exports = {
  all: all,
  get: get,
  save: save,
  remove: remove,
  query: query,
  random: random,
  categoryName: categoryName,
  recordCook: recordCook
}
