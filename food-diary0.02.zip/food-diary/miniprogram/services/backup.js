// 备份与恢复：把本地所有 fd.* 数据打包成一份 JSON 文本。
// 注意：只备份文字。图片存在文件系统里，无法塞进文本通道。

const storage = require('./storage')
const schema = require('../store/schema')
const media = require('./media')
const { formatDate } = require('../utils/date')

const PREFIX = 'fd.'
const BACKUP_DIR = wx.env.USER_DATA_PATH + '/fd/backup'

function fs() {
  return wx.getFileSystemManager()
}

// 通用：扫描所有 fd. 前缀的 key，而不是写死列表。
// 这样以后新增数据类型（周菜单、采购清单…）会自动被备份覆盖，无需改这里。
function isDataKey(key) {
  return key.indexOf(PREFIX) === 0 && key !== storage.KEYS.draft
}

function collectKeys() {
  let keys = []
  try {
    keys = (wx.getStorageInfoSync().keys || [])
  } catch (e) {}
  return keys.filter(isDataKey)
}

function exportPayload() {
  const data = {}
  collectKeys().forEach(function (key) {
    data[key] = storage.get(key, null)
  })
  return {
    app: 'food-diary',
    schemaVersion: schema.SCHEMA_VERSION,
    exportedAt: Date.now(),
    data: data
  }
}

function serialize() {
  return JSON.stringify(exportPayload(), null, 2)
}

function ensureBackupDir() {
  try {
    fs().accessSync(BACKUP_DIR)
  } catch (e) {
    try {
      fs().mkdirSync(BACKUP_DIR, true)
    } catch (e2) {}
  }
}

// 写入本地文件，返回绝对路径（供分享用）
function writeBackupFile() {
  ensureBackupDir()
  const name = 'backup-' + formatDate(Date.now()) + '.txt'
  const filePath = BACKUP_DIR + '/' + name
  fs().writeFileSync(filePath, serialize(), 'utf8')
  return filePath
}

function parse(text) {
  let obj = null
  try {
    obj = JSON.parse(text)
  } catch (e) {
    throw new Error('不是合法的备份文件')
  }
  if (!obj || !obj.data || typeof obj.data !== 'object') {
    throw new Error('备份内容格式不对')
  }
  return obj
}

function countRecipes(payload) {
  const list = payload.data[storage.KEYS.recipes]
  return Array.isArray(list) ? list.length : 0
}

// 导入的菜谱里的图片路径，在本机大概率不存在。
// 逐张检查：本机有就保留（同机恢复的场景），没有就丢掉，避免显示成裂图。
function sanitizeRecipes(list) {
  const fsm = fs()
  const exists = function (rel) {
    if (!rel) return false
    try {
      fsm.accessSync(media.absPath(rel))
      return true
    } catch (e) {
      return false
    }
  }

  return (list || []).map(function (r) {
    const copy = Object.assign({}, r)
    copy.cover = exists(r.cover) ? r.cover : ''
    copy.steps = (r.steps || []).map(function (s) {
      return Object.assign({}, s, {
        images: (s.images || []).filter(exists)
      })
    })
    return copy
  })
}

// mode: 'merge'（默认，按 id 去重，保留本机）| 'replace'（清空后覆盖）
function applyImport(payload, mode) {
  const incoming = payload.data || {}
  const recipesKey = storage.KEYS.recipes

  if (mode === 'replace') {
    collectKeys().forEach(function (key) { storage.remove(key) })

    const recipes = sanitizeRecipes(incoming[recipesKey] || [])
    Object.keys(incoming).forEach(function (key) {
      if (!isDataKey(key)) return
      storage.set(key, key === recipesKey ? recipes : incoming[key])
    })

    media.gc(media.collectUsed(recipes))
    markBackedUp()
    return { mode: 'replace', added: recipes.length, skipped: 0 }
  }

  let added = 0
  let skipped = 0

  Object.keys(incoming).forEach(function (key) {
    if (!isDataKey(key)) return
    const inc = incoming[key]

    if (Array.isArray(inc)) {
      const current = storage.get(key, [])
      const seen = {}
      current.forEach(function (item) {
        if (item && item.id) seen[item.id] = true
      })

      const list = key === recipesKey ? sanitizeRecipes(inc) : inc
      list.forEach(function (item) {
        if (item && item.id && seen[item.id]) {
          skipped++
          return
        }
        current.push(item)
        added++
      })
      storage.set(key, current)
    } else if (storage.get(key, null) === null) {
      storage.set(key, inc)
      added++
    }
  })

  media.gc(media.collectUsed(storage.get(recipesKey, [])))
  markBackedUp()
  return { mode: 'merge', added: added, skipped: skipped }
}

function markBackedUp() {
  const settings = storage.get(storage.KEYS.settings, {})
  settings.lastBackupAt = Date.now()
  storage.set(storage.KEYS.settings, settings)
}

function lastBackupAt() {
  const settings = storage.get(storage.KEYS.settings, {})
  return settings.lastBackupAt || 0
}

module.exports = {
  writeBackupFile: writeBackupFile,
  serialize: serialize,
  exportPayload: exportPayload,
  parse: parse,
  countRecipes: countRecipes,
  applyImport: applyImport,
  markBackedUp: markBackedUp,
  lastBackupAt: lastBackupAt
}
