const media = require('../../services/media')

Component({
  properties: {
    recipe: {
      type: Object,
      value: {}
    }
  },

  data: {
    coverSrc: '',
    tags: []
  },

  observers: {
    'recipe': function (recipe) {
      this.setData({
        coverSrc: recipe && recipe.cover ? media.absPath(recipe.cover) : '',
        tags: (recipe && recipe.tags ? recipe.tags : []).slice(0, 3)
      })
    }
  },

  methods: {
    onTap() {
      this.triggerEvent('open', { id: this.data.recipe.id })
    }
  }
})
