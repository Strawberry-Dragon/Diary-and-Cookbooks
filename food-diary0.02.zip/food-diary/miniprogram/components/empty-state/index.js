Component({
  properties: {
    text: {
      type: String,
      value: '这里还什么都没有'
    },
    buttonText: {
      type: String,
      value: ''
    }
  },

  methods: {
    onTap() {
      this.triggerEvent('action')
    }
  }
})
