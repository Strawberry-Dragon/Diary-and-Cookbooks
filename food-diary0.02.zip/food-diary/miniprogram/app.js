const storage = require('./services/storage')
const media = require('./services/media')

App({
  onLaunch() {
    // 初始化存储：建目录、补齐默认设置、清理孤立图片
    storage.init()
    media.ensureDirs()

    const recipes = storage.get(storage.KEYS.recipes, [])
    media.gc(media.collectUsed(recipes))
  },

  globalData: {
    // 页面间少量临时共享数据放这里，正式数据一律走 services
  }
})
