// 冒烟测试：用假的 wx 全局跑一遍 services 层，验证查询/排序/保存逻辑
// 运行：node smoke-test.js（需 Node 14+）
const path = require('path')
const mem = {}
const files = new Set()
const written = {}

global.wx = {
  env: { USER_DATA_PATH: 'wxfile://usr' },
  getStorageSync(k) { return mem[k] === undefined ? '' : mem[k] },
  setStorageSync(k, v) { mem[k] = v },
  removeStorageSync(k) { delete mem[k] },
  getStorageInfoSync() { return { keys: Object.keys(mem), currentSize: 12, limitSize: 10240 } },
  getFileSystemManager() {
    return {
      // 虚拟文件系统：只有加进 files 的路径才"存在"，用来验证备份时的图片清理逻辑
      accessSync(p) { if (!files.has(p)) { const e = new Error('no such file'); throw e } },
      mkdirSync() {},
      unlinkSync(p) { files.delete(p) },
      readdirSync() { return [] },
      writeFileSync(p, data) { files.add(p); written[p] = data },
      readFileSync(p) { return written[p] === undefined ? '' : written[p] },
      saveFile(o) { files.add(o.filePath); o.success && o.success({ savedFilePath: o.filePath }) }
    }
  },
  showToast() {}, chooseMedia() {}, compressImage() {}, getImageInfo() {},
  setKeepScreenOn() {}, setNavigationBarTitle() {}, navigateBack() {},
  vibrateLong() { vibrateCount++ },
  showModal(o) { modalCalls.push(o); o.success && o.success({ confirm: true }) },
  createSelectorQuery() {
    const chain = { in() { return chain }, select() { return chain }, fields() { return chain }, exec() {} }
    return chain
  }
}

let vibrateCount = 0
const modalCalls = []
let capturedPage = null
global.Page = function (cfg) { capturedPage = cfg }

const base = path.join(__dirname, 'miniprogram')
const storage = require(path.join(base, 'services/storage'))
const recipeService = require(path.join(base, 'services/recipe'))
const media = require(path.join(base, 'services/media'))
const schema = require(path.join(base, 'store/schema'))

let pass = 0
let fail = 0
function check(name, cond, extra) {
  if (cond) { pass++; console.log('  PASS  ' + name) }
  else { fail++; console.log('  FAIL  ' + name + (extra !== undefined ? '  -> ' + JSON.stringify(extra) : '')) }
}

storage.init()
check('init 写入默认设置', !!storage.get(storage.KEYS.settings, null))
check('init 初始化空数组', Array.isArray(storage.get(storage.KEYS.recipes, null)))

const a = recipeService.save(schema.createRecipe({ title: '番茄牛腩', tags: ['下饭'], cookCount: 7, rating: 5, durationMin: 90 }))
const b = recipeService.save(schema.createRecipe({ title: '蒜香黄油虾', tags: ['快手'], cookCount: 3, rating: 4 }))
recipeService.save(schema.createRecipe({ title: '味噌汤', categoryId: 'c_02', cookCount: 12, rating: 4 }))

check('保存后 id 自动生成', !!a.id && !!b.id)
check('总数 3 条', recipeService.all().length === 3, recipeService.all().length)

check('关键词命中菜名', recipeService.query({ keyword: '牛腩' }).length === 1)
check('关键词命中标签', recipeService.query({ keyword: '快手' }).length === 1)
check('关键词命中食材', (function () {
  const r = recipeService.get(a.id)
  r.ingredients = [{ name: '牛腩', amount: '500', unit: 'g', optional: false }]
  recipeService.save(r)
  return recipeService.query({ keyword: '牛腩' }).length === 1
})())
check('分类筛选', recipeService.query({ categoryId: 'c_02' }).length === 1)
check('按做得最多排序', recipeService.query({ sortBy: 'most' })[0].title === '味噌汤')
check('按评分排序', recipeService.query({ sortBy: 'rating' })[0].title === '番茄牛腩')

recipeService.recordCook(b.id, 5)
check('记一次下厨后次数 +1', recipeService.get(b.id).cookCount === 4, recipeService.get(b.id).cookCount)
check('写入 CookLog', storage.get(storage.KEYS.logs, []).length === 1)
check('分类名解析', recipeService.categoryName('c_02') === '汤羹')

recipeService.remove(a.id)
check('删除后剩 2 条', recipeService.all().length === 2)

const q = storage.getQuota()
check('配额返回可用文本', q.currentText.indexOf('MB') > 0, q)

// ---- 烹饪模式计时器 ----

require(path.join(base, 'pages/cooking/index'))

function makePage(cfg) {
  const inst = Object.assign({}, cfg)
  inst.data = JSON.parse(JSON.stringify(cfg.data))
  inst.setData = function (obj) { Object.assign(inst.data, obj) }
  return inst
}

const cooked = recipeService.save(schema.createRecipe({
  title: '测试菜',
  steps: [
    { text: '焯水', images: [], timerSec: 60 },
    { text: '慢炖', images: [], timerSec: 3600 },
    { text: '收汁', images: [], timerSec: 0 }
  ],
  ingredients: [{ name: '牛腩', amount: '500', unit: 'g', optional: false }]
}))

const page = makePage(capturedPage)
page.onLoad({ id: cooked.id })

check('烹饪页加载步骤', page.data.total === 3, page.data.total)
check('首步计时器 = 60 秒', page.data.timerTotal === 60, page.data.timerTotal)
check('60 秒格式化为 01:00', page.data.clockText === '01:00', page.data.clockText)
check('首步进度 33%', page.data.percent === 33, page.data.percent)

page.startTimer()
check('开始后进入运行态', page.data.timerRunning === true)

page.timerEndAt = Date.now() + 2000
page.tick()
check('按时间戳算出剩余 2 秒', page.data.timerLeft === 2, page.data.timerLeft)

page.timerEndAt = Date.now() + 3000
page.pauseTimer()
check('暂停后保留剩余 3 秒', page.data.timerLeft === 3, page.data.timerLeft)
check('暂停后停止运行', page.data.timerRunning === false)

page.onTimerToggle()
check('再点一次恢复运行', page.data.timerRunning === true)

page.timerEndAt = Date.now() - 10
page.tick()
check('归零后停止', page.data.timerRunning === false)
check('归零显示 00:00', page.data.clockText === '00:00', page.data.clockText)
check('归零触发震动', vibrateCount === 1, vibrateCount)

page.resetTimer()
check('重置回到满值', page.data.timerLeft === 60, page.data.timerLeft)

page.next()
check('切到第二步', page.data.stepIndex === 1, page.data.stepIndex)
check('第二步计时器 3600 秒', page.data.timerTotal === 3600, page.data.timerTotal)
check('3600 秒格式化为 01:00:00', page.data.clockText === '01:00:00', page.data.clockText)

page.next()
check('第三步无计时', page.data.timerTotal === 0, page.data.timerTotal)
check('末步标记为最后一步', page.data.isLast === true)

page.next()
check('完成后弹出记录询问', modalCalls.length === 1, modalCalls.length)

// ---- 备份与恢复 ----

const backup = require(path.join(base, 'services/backup'))

const filePath = backup.writeBackupFile()
check('备份文件已生成', typeof filePath === 'string' && filePath.indexOf('backup-') >= 0, filePath)
check('备份内容可解析', backup.parse(written[filePath]).app === 'food-diary')

const payload = backup.exportPayload()
check('备份含菜谱数据', Array.isArray(payload.data[storage.KEYS.recipes]))
check('备份含下厨记录', Array.isArray(payload.data[storage.KEYS.logs]))
check('备份不含草稿', payload.data[storage.KEYS.draft] === undefined)
check('备份带版本号', payload.schemaVersion === schema.SCHEMA_VERSION)

check('从未备份时返回 0', backup.lastBackupAt() === 0)

recipeService.save(schema.createRecipe({ title: '重复项', id: 'r_dup_1' }))
const mergeResult = backup.applyImport({
  app: 'food-diary',
  schemaVersion: 1,
  exportedAt: Date.now(),
  data: {
    [storage.KEYS.recipes]: [
      { id: 'r_dup_1', title: '重复项(备份里的)', steps: [], ingredients: [] },
      { id: 'r_new_1', title: '新菜', steps: [], ingredients: [] }
    ]
  }
}, 'merge')

check('合并新增 1 条', mergeResult.added === 1, mergeResult)
check('合并跳过重复 1 条', mergeResult.skipped === 1, mergeResult)
check('重复项保留本机版本', recipeService.get('r_dup_1').title === '重复项', recipeService.get('r_dup_1').title)
check('新菜已导入', !!recipeService.get('r_new_1'))
check('备份后记录时间戳', backup.lastBackupAt() > 0)

// 图片路径清理：本机没有的图片必须丢掉，否则会显示成裂图
const existsImg = 'fd/cover/exists.jpg'
files.add(media.absPath(existsImg))
backup.applyImport({
  app: 'food-diary',
  schemaVersion: 1,
  exportedAt: Date.now(),
  data: {
    [storage.KEYS.recipes]: [
      { id: 'r_img_keep', title: '同机恢复', cover: existsImg, steps: [{ text: 'a', images: [existsImg] }] },
      { id: 'r_img_drop', title: '换机恢复', cover: 'fd/cover/missing.jpg', steps: [{ text: 'b', images: ['fd/cover/missing.jpg'] }] }
    ]
  }
}, 'merge')

check('本机存在的图片保留', recipeService.get('r_img_keep').cover === existsImg, recipeService.get('r_img_keep').cover)
check('本机缺失的封面被清除', recipeService.get('r_img_drop').cover === '', recipeService.get('r_img_drop').cover)
check('本机缺失的步骤图被清除', recipeService.get('r_img_drop').steps[0].images.length === 0)

const replaceResult = backup.applyImport({
  app: 'food-diary',
  schemaVersion: 1,
  exportedAt: Date.now(),
  data: {
    [storage.KEYS.recipes]: [{ id: 'r_only', title: '仅此一道', steps: [], ingredients: [] }]
  }
}, 'replace')

check('覆盖模式清空旧数据', replaceResult.added === 1, replaceResult)
check('覆盖后只剩一道菜', recipeService.all().length === 1, recipeService.all().length)

let threw = false
try { backup.parse('这不是 JSON') } catch (e) { threw = true }
check('非法内容被拒绝', threw)

// ---- 第 3 周：日历统计 / 采购清单 / 周菜单 ----

const stats = require(path.join(base, 'services/stats'))
const shopping = require(path.join(base, 'services/shopping'))
const plan = require(path.join(base, 'services/plan'))
const { formatDate } = require(path.join(base, 'utils/date'))

const r1 = recipeService.save(schema.createRecipe({ title: 'A菜', cookCount: 5 }))
const r2 = recipeService.save(schema.createRecipe({ title: 'B菜', cookCount: 9 }))
const r3 = recipeService.save(schema.createRecipe({ title: 'C菜', cookCount: 2 }))

check('topRecipes 按 cookCount 降序', stats.topRecipes(3).map(function (r) { return r.title }).join(',') === 'B菜,A菜,C菜', stats.topRecipes(3).map(function (r) { return r.title }))

const today = formatDate(new Date())
const yesterday = formatDate(new Date(Date.now() - 86400000))
const d = new Date()
const lastMonth = formatDate(new Date(d.getFullYear(), d.getMonth() - 1, 15))
storage.set(storage.KEYS.logs, [
  { id: 'l1', recipeId: r1.id, date: today, rating: 5, note: '', photos: [], createdAt: Date.now() },
  { id: 'l2', recipeId: r2.id, date: today, rating: 4, note: '', photos: [], createdAt: Date.now() },
  { id: 'l3', recipeId: r3.id, date: yesterday, rating: 0, note: '', photos: [], createdAt: Date.now() },
  { id: 'l4', recipeId: r1.id, date: lastMonth, rating: 0, note: '', photos: [], createdAt: Date.now() }
])

check('monthGrid 返回 42 格', stats.monthGrid(d.getFullYear(), d.getMonth() + 1).length === 42)
check('groupByDate 今天计数=2', stats.groupByDate()[today] === 2, stats.groupByDate())
check('streak 连续天数=2（今+昨）', stats.streak() === 2, stats.streak())
check('monthCount 本月=3', stats.monthCount(d.getFullYear(), d.getMonth() + 1) === 3, stats.monthCount(d.getFullYear(), d.getMonth() + 1))
check('dayLogs 返回当天记录', stats.dayLogs(today).length === 2)
check('summary 累加起来', stats.summary(d.getFullYear(), d.getMonth() + 1).totalCook === 4)

// 采购清单
storage.set(storage.KEYS.shopping, [])
const s1 = shopping.add({ name: '牛腩', amount: '500', unit: 'g' })
shopping.add({ name: '番茄', amount: '3', unit: '个' })
check('采购新增 2 项', shopping.all().length === 2, shopping.all().length)
shopping.toggle(s1.id)
check('勾选后 checked=true', shopping.all().filter(function (i) { return i.checked }).length === 1)
shopping.clearChecked()
check('清空已购后剩 1 项', shopping.all().length === 1, shopping.all().length)

// 同类食材合并：清单里保留牛腩 500g，导入菜谱里牛腩 300g → 800g
storage.set(storage.KEYS.shopping, [])
shopping.add({ name: '牛腩', amount: '500', unit: 'g' })
const r1b = recipeService.get(r1.id)
r1b.ingredients = [{ name: '牛腩', amount: '300', unit: 'g', optional: false }]
recipeService.save(r1b)
const imp = shopping.importFromRecipes([r1.id])
const beef = shopping.all().filter(function (i) { return i.name === '牛腩' })[0]
check('同类食材合并 500+300=800', beef.amount === '800', beef.amount)
check('合并不计新增（added=0, merged=1）', imp.added === 0 && imp.merged === 1, imp)

// 清单里没有的食材正常新增
const r2b = recipeService.get(r2.id)
r2b.ingredients = [{ name: '鸡蛋', amount: '4', unit: '个', optional: false }]
recipeService.save(r2b)
const imp2 = shopping.importFromRecipes([r2.id])
check('清单里没有的食材正常新增', imp2.added === 1 && imp2.merged === 0, imp2)

// 周菜单
storage.set(storage.KEYS.plans, [])
const wd = plan.weekDates()
plan.assign(wd[0], 'dinner', r1.id)
const dinner0 = plan.weekBoard()[0].meals.filter(function (m) { return m.key === 'dinner' })[0]
check('周菜单分配后 weekBoard 显示菜名', dinner0.title === 'A菜', dinner0)
plan.toggleDone(dinner0.planId)
check('周菜单标记完成 done=true', plan.weekBoard()[0].meals.filter(function (m) { return m.key === 'dinner' })[0].done === true)
plan.assign(wd[0], 'dinner', '')
check('清空格子后标题置空', plan.weekBoard()[0].meals.filter(function (m) { return m.key === 'dinner' })[0].title === '')

// 每日随机菜品
const rTotal = recipeService.all().length
check('库里有菜谱可随机', rTotal >= 1, rTotal)
const rPick = recipeService.random(2)
check('随机 2 道长度正确', rPick.length === Math.min(2, rTotal), rPick.length)
let dup = false
for (let i = 0; i < rPick.length; i++) {
  for (let j = i + 1; j < rPick.length; j++) {
    if (rPick[i].id === rPick[j].id) dup = true
  }
}
check('随机结果无重复', !dup, rPick.map(function (r) { return r.id }))
const rOver = recipeService.random(9999)
check('数量超过总数时返回全部', rOver.length === rTotal, rOver.length)
check('随机 0 道返回空', recipeService.random(0).length === 0)
check('随机负数返回空', recipeService.random(-3).length === 0)

console.log('\n结果: ' + pass + ' 通过, ' + fail + ' 失败')
process.exit(fail ? 1 : 0)
